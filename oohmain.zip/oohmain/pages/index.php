<?php
include ("connect.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CDL MAIN</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">
<style type="text/css">
    
</style>
    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
.navbar-default {
     background-color:transparent;
    border-color: #e7e7e7;
}
.form-group.required .control-label1:after {
  content:"nssf*";
  color:red;
}
.form-group.required .control-label2:after {
  content:"nhif*";
  color:red;
}

</style>
</head>


<body>

    <div id="wrapper">

         <?php include_once('partial.php');?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Register New Organisation</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                
                   <form role="form"  action="index.php" method="post" enctype="multipart/form-data">
                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Name:</label>
                                            <input class="form-control" type="text" name="name" placeholder="Enter Name">
                                        </div>
                                        <div class="form-group">
                                            <label>TaxId:</label>
                                            <input class="form-control"  type="text" name="taxid" placeholder="Enter TaxId">
                                        </div>
                                         <div class="form-group required">
                                            <label class="control-label1">Registration Number:</label>
                                            <input class="form-control"  type="text" name="regno" placeholder="Enter Registration No NSSF">
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label1">Phone:</label>
                                            <input class="form-control"  type="text" name="phone" placeholder="Enter Phone">
                                        </div>
                                       
                                       
                                       
                                       
            </div>
             <div class="col-md-4">
                
                                        <div class="form-group">
                                            <label>Fax:</label>
                                            <input class="form-control" type="text" name="fax" placeholder="Enter Fax">
                                        </div>
                                        <div class="form-group">
                                            <label>Email:</label>
                                            <input class="form-control"  type="email" name="email" placeholder="Enter Email">
                                        </div>
                                         <div class="form-group">
                                            <label>Country:</label>
                                           <select class="form-control" id="sel1" name="country">
        <option>KE</option>
        <option>UD</option>
        <option>SOM</option>
        <option>SA</option>
      </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Province:</label>
                                           <select class="form-control" id="sel1" name="province">
        <option>Eastern</option>
        <option>Central</option>
        <option>Nyanza</option>
        <option>Western</option>
      </select> 
                                        </div>
                                       
                                       
                                       
            </div>
             <div class="col-md-4">
                                        <div class="form-group">
                                            <label>City:</label>
                                            <select class="form-control" id="sel1" name="city">
        <option>Nairobi</option>
        <option>Kampala</option>
        <option>Kisumu</option>
        <option>Mombasa</option>
      </select>
                                        </div>
                                        <div class="form-group ">
                                            <label>Zip Code:</label>
                                            <input class="form-control"  type="text" placeholder="Enter Zip Code" name="zip">
                                        </div>
                                         <div class="form-group">
                                            <label>Street:</label>
                                            <input class="form-control"  type="text" placeholder="Enter Street" name="strone">
                                        </div>
                                        <div class="form-group required">
                                            <label class="control-label2">NHIF</label>
                                            <input class="form-control"  type="text" placeholder="Enter NHIF" name="strtwo">
                                        </div>
                                         <div class="form-group">
                                            <label>Note:</label>
                                            <input class="form-control"  type="text" placeholder="Enter Note" name="note">
                                        </div>
                                       
                                        
                                       
                                       
                                       
            </div>
             
                </div>
                
           <div>
               <input type="submit" class="btn btn-success" name="insert_org" value="Save"/>
               <input type="submit" class="btn btn-danger" name="dublicate" value="Dublicate "/>
        </div>
        </form>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
<?php
include ("connect.php");
  if(isset($_POST['insert_org'])){
 
 //getting the text data from fields

$name=$_POST['name'];
$taxid=$_POST['taxid'];
$regno=$_POST['regno'];
$phone=$_POST['phone'];
$fax=$_POST['fax'];
$email=$_POST['email'];
$country=$_POST['country'];
$province=$_POST['province'];
$city=$_POST['city'];
$zip=$_POST['zip'];
$strone=$_POST['strone'];
$strtwo=$_POST['strtwo'];
$note=$_POST['note'];



 $insert_product="insert into ohrm_organization_gen_info (name,tax_id,registration_number,phone,fax,email,country,province,city,zip_code,street1,street2,note)
     values('$name','$taxid','$regno','$phone','$fax','$email','$country','$province','$city','$zip','$strone','$strtwo','$note')";
      

      $insert_pro=mysqli_query($con,$insert_product);

      if($insert_pro){
        echo "<script>alert('Organisation has been Inserted!')</script>";
        echo "<script>window.open('index.php','_self')</script>";

      }else{
         echo "<script>alert('Organisation failed !')</script>";
      }
   
  }

 else if(isset($_POST['dublicate'])){
/********************* START CONFIGURATION *********************/
$DB_SRC_HOST='localhost';
$DB_SRC_USER='root';
$DB_SRC_PASS='';
$DB_SRC_NAME='grandways_hr';
$DB_DST_HOST='localhost';
$DB_DST_USER='root';
$DB_DST_PASS='';
$DB_DST_NAME='orangehrm';

/*********************** GRAB OLD SCHEMA ***********************/
$db1 = new mysqli ($DB_SRC_HOST,$DB_SRC_USER,$DB_SRC_PASS) or die($db1->error);
mysqli_select_db($db1,$DB_SRC_NAME) or die($db1->error);
$result = mysqli_query($db1,"SHOW TABLES;") or die($db1->error);
$buf="set foreign_key_checks = 0;\n";
$constraints='';
while($row = mysqli_fetch_array($result))
{
    $result2 = mysqli_query($db1,"SHOW CREATE TABLE ".$row[0].";") or die($db1->error);
    $res = mysqli_fetch_array($result2);
    if(preg_match("/[ ]*CONSTRAINT[ ]+.*\n/",$res[1],$matches))
    {
        $res[1] = preg_replace("/,\n[ ]*CONSTRAINT[ ]+.*\n/","\n",$res[1]);
        $constraints.="ALTER TABLE ".$row[0]." ADD ".trim($matches[0]).";\n";
    }
    $buf.=$res[1].";\n";
}
$buf.=$constraints;
$buf.="set foreign_key_checks = 1";

/**************** CREATE NEW DB WITH OLD SCHEMA ****************/
$db2 = new mysqli($DB_DST_HOST,$DB_DST_USER,$DB_DST_PASS) or die($db2->error);
$sql = 'CREATE DATABASE '.$DB_DST_NAME;
if(!mysqli_query($db2,$sql)) die($db2->error);
mysqli_select_db($db2,$DB_DST_NAME) or die($db2->error);
$queries = explode(';',$buf);
foreach($queries as $query)
{
    if(!mysqli_query($db2,$query)) die($db2->error);
}

  }

?>
