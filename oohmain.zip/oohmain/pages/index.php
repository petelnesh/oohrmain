<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TRACK OOH</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../vendor/morrisjs/morris.css" rel="stylesheet">
<style type="text/css">
    
</style>
    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
.navbar-default {
     background-color:transparent;
    border-color: #e7e7e7;
}
</style>
</head>


<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"><img src="../images/logo-dark.png" width="150" height="50" alt="logo"/></a>
            </div>
           

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="allorganisation.php"><i class="fa fa-dashboard fa-fw"></i> All Organisations</a>
                        </li>
                        
                        
                        
                       
                            </ul>
                         
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Register New Organisation</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-md-4">
                   <form role="form">
                                        <div class="form-group">
                                            <label>Name:</label>
                                            <input class="form-control" placeholder="Enter Name">
                                        </div>
                                        <div class="form-group">
                                            <label>TaxId:</label>
                                            <input class="form-control" placeholder="Enter TaxId">
                                        </div>
                                         <div class="form-group">
                                            <label>Registration Number:</label>
                                            <input class="form-control" placeholder="Enter Name">
                                        </div>
                                        <div class="form-group">
                                            <label>Phone:</label>
                                            <input class="form-control" placeholder="Enter TaxId">
                                        </div>
                                       
                                       
                                       
            </div>
             <div class="col-md-4">
                   <form role="form">
                                        <div class="form-group">
                                            <label>Fax:</label>
                                            <input class="form-control" placeholder="Enter Name">
                                        </div>
                                        <div class="form-group">
                                            <label>Email:</label>
                                            <input class="form-control" placeholder="Enter TaxId">
                                        </div>
                                         <div class="form-group">
                                            <label>Country:</label>
                                           <select class="form-control" id="sel1">
        <option>KE</option>
        <option>UD</option>
        <option>SOM</option>
        <option>SA</option>
      </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Province:</label>
                                           <select class="form-control" id="sel1">
        <option>Eastern</option>
        <option>Central</option>
        <option>Nyanza</option>
        <option>Western</option>
      </select> 
                                        </div>
                                       
                                       
                                       
            </div>
             <div class="col-md-4">
                   <form role="form">
                                        <div class="form-group">
                                            <label>City:</label>
                                            <select class="form-control" id="sel1">
        <option>Nairobi</option>
        <option>Kampala</option>
        <option>Kisumu</option>
        <option>Mombasa</option>
      </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Zip Code:</label>
                                            <input class="form-control" placeholder="Enter TaxId">
                                        </div>
                                         <div class="form-group">
                                            <label>Street1:</label>
                                            <input class="form-control" placeholder="Enter Name">
                                        </div>
                                        <div class="form-group">
                                            <label>Street2:</label>
                                            <input class="form-control" placeholder="Enter TaxId">
                                        </div>
                                       
                                       
                                       
            </div>
            </form> 
                </div>
                
           <div>
               <p class="btn btn-success">Save</p>
               <p class="btn btn-danger">Cancel</p>
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../vendor/raphael/raphael.min.js"></script>
    <script src="../vendor/morrisjs/morris.min.js"></script>
    <script src="../data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
